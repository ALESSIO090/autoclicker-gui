Autocliccker GUI - by Pozie

🔹 COME USARLO:
1. Avvia autocliccker_gui.exe
2. Inserisci la velocità dei click (in secondi o millisecondi)
3. Premi 'Avvia' per iniziare e 'Ferma' per fermare
4. Premi F11 per minimizzare o uscire dalla modalità schermo intero

🔹 TASTI RAPIDI:
- F11: Minimizza
- ESC: Esci completamente

✅ Versione: 1.0
