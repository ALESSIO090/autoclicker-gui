
# AutoClicker GUI

A simple graphical autoclicker tool built with Python and Tkinter.  
Allows easy control of mouse clicks with customizable speed in seconds or milliseconds.

## Features
- Start and stop clicking with buttons
- Adjustable click interval
- Fullscreen mode (F11 to toggle, ESC to exit)
- Clean, aesthetic interface

## How to Run
1. Install Python 3 if you haven't already.
2. Run with:
```bash
python autoclicker_gui.py
```

## Shortcut
- **F11** → Toggle fullscreen
- **ESC** → Exit fullscreen
