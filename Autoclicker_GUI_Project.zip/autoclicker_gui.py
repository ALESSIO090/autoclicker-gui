
import pyautogui
import threading
import time
import tkinter as tk

clicking = False
delay = 0.1

def start_clicking():
    global clicking
    clicking = True
    status_label.config(text="Status: ACTIVE")

def stop_clicking():
    global clicking
    clicking = False
    status_label.config(text="Status: Paused")

def set_speed():
    global delay
    try:
        value = float(speed_entry.get())
        delay = value
        status_label.config(text=f"Speed set to {delay} sec between clicks")
    except ValueError:
        status_label.config(text="Error: Enter a valid number")

def click_loop():
    while True:
        if clicking:
            pyautogui.click()
            time.sleep(delay)
        else:
            time.sleep(0.1)

def toggle_fullscreen(event=None):
    global fullscreen
    fullscreen = not fullscreen
    root.attributes("-fullscreen", fullscreen)

def exit_fullscreen(event=None):
    global fullscreen
    fullscreen = False
    root.attributes("-fullscreen", False)

click_thread = threading.Thread(target=click_loop)
click_thread.daemon = True
click_thread.start()

root = tk.Tk()
root.title("Autoclicker GUI")
root.geometry("400x300")
fullscreen = False

tk.Label(root, text="Click speed (sec or ms):", font=("Arial", 12)).pack(pady=10)
speed_entry = tk.Entry(root, font=("Arial", 12))
speed_entry.insert(0, "0.1")
speed_entry.pack(pady=5)

tk.Button(root, text="Start", command=start_clicking, bg="green", fg="white", font=("Arial", 12)).pack(pady=5)
tk.Button(root, text="Stop", command=stop_clicking, bg="red", fg="white", font=("Arial", 12)).pack(pady=5)
tk.Button(root, text="Set Speed", command=set_speed, font=("Arial", 12)).pack(pady=5)

status_label = tk.Label(root, text="Status: Paused", font=("Arial", 12))
status_label.pack(pady=10)

root.bind("<F11>", toggle_fullscreen)
root.bind("<Escape>", exit_fullscreen)

root.mainloop()
